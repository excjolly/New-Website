export { default as Home } from "./home/Home";
export { default as Blogs } from "./blogs/Blogs";
export { default as BlogDetails } from "./blogs/BlogDetails";
