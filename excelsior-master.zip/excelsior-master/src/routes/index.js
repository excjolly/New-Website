export { default as AppRoutes } from "./AppRoutes";
